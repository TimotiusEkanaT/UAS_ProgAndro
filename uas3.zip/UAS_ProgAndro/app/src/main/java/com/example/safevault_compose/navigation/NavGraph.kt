package com.example.safevault_compose.navigation



import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.safevault_compose.LoginFaceid
import com.example.safevault_compose.LoginFingerprint
import com.example.safevault_compose.Notes
import com.example.safevault_compose.NotesDetail
import com.example.safevault_compose.NotesBlank
import com.example.safevault_compose.Setting
import com.example.safevault_compose.FaceIDSettingScreen
import com.example.safevault_compose.FingerprintSettingScreen
import com.example.safevault_compose.CalculatorSettingScreen


@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "notes") {

        //Notes ke NotesDetail
        composable("notes") {
            Notes(
                onNavigateToNotesDetail = {navController.navigate("notes_detail")},
                onNavigateToSetting = {navController.navigate("setting")}
            )
        }


        //NotesDetail back to Notes
        composable("notes_detail") {
            NotesDetail(
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        // Use FaceID pada LoginFingerprint ke LoginFaceID
        composable("login_fingerprint"){
            LoginFingerprint(
                onUseFaceID = {navController.navigate("login_faceid")}
            )
        }

        //Cancel pada LoginFaceID ke LoginFingerprint
        composable("login_faceid"){
            LoginFaceid(onCancel = {
                navController.popBackStack() //kembali ke LoginFingerprint
            }
            )
        }

        //NotesBlank
        composable("notes_black"){
            NotesBlank(
                onBackToNotes = {navController.navigate("notes")},
                onSave = {/*save note dan kembali */ navController.popBackStack()},
                onCancel = {navController.popBackStack()}
            )
        }

        //Setting ke FaceId, Fingerprint,Calculator
        composable("setting"){
            Setting(
                onBackToNotes = { navController.navigate("notes") },
                onFaceIDClick = { navController.navigate("face_id_setting") },
                onFingerprintClick = { navController.navigate("fingerprint_setting") },
                onCalculatorClick = { navController.navigate("calculator_setting") }
            )
        }
        // Rute-rute tujuan masing-masing tombol
        composable("face_id_setting") {
            // Halaman pengaturan Face ID
            FaceIDSettingScreen(onBack = { navController.popBackStack() })
        }

        composable("fingerprint_setting") {
            // Halaman pengaturan Fingerprint
            FingerprintSettingScreen(onBack = { navController.popBackStack() })
        }

        composable("calculator_setting") {
            // Halaman pengaturan Kalkulator
            CalculatorSettingScreen(onBack = { navController.popBackStack() })
        }



    }
}

@Composable
fun AppNavHost(){
    val navController = rememberNavController()
    NavGraph(navController = navController)
}